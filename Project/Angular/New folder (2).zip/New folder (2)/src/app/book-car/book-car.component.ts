import { Component } from '@angular/core';

@Component({
  selector: 'app-book-car',
  standalone: true,
  imports: [],
  templateUrl: './book-car.component.html',
  styleUrl: './book-car.component.css'
})
export class BookCarComponent {

}
