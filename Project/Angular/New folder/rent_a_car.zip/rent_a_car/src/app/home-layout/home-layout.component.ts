import {Component, HostListener} from '@angular/core';
import {NgClass} from "@angular/common";
import {RouterLink} from "@angular/router";

@Component({
  selector: 'app-home-layout',
  standalone: true,
  imports: [
    NgClass,
    RouterLink
  ],
  templateUrl: './home-layout.component.html',
  styleUrl: './home-layout.component.css'
})
export class HomeLayoutComponent {
  isDropdownOpen = false;
  isMenubarOpen = false;

  navItems = [
    {
      navName: "Cars",
      navLink : 'car'
    },
    {
      navName: "Cars",
      navLink : 'car'
    },
    {
      navName: "Register",
      navLink : 'register'
    }
  ]

  toggleDropdown(){
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  toggleMenubar(){
    this.isMenubarOpen = !this.isMenubarOpen;
  }

  @HostListener('document:click', ['$event'])
  onClick(event: MouseEvent){
    const target = event.target as HTMLElement;
    const clickedInside = target.closest('.relative');
    if(!clickedInside){
      this.isDropdownOpen = false;
    }
  }

}
